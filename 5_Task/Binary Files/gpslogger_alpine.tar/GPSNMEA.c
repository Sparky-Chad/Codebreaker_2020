#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#define FIFO "/tmp/gps_fifo"

// A struct to more easily pass information through the fifo
struct lineread
{
    // Contains the size of the char buffer it points to
    int size;
    char* buffer;
};

int gpsnmea_counter = 0;
char* GPSNMEA();
struct lineread readline(FILE* ifile, char* buffer);

int main() {
    char *c;
    
    c = GPSNMEA();
    
    for(int i = 0; c[i] != '\0'; i++)
    {
        printf("%c", c[i]);
    }
    
    // free c
    free(c);
}

// Fake gpsoutput, reading characters from fifo
char *GPSNMEA() {
    // set up file reader object
    FILE *ifile;
    long filelen;
    char *buffer;
    char *output;
    struct lineread temp;
    
    ifile = fopen(FIFO, "r");
    filelen = 64;
    
    // Initial buffer which will serve to initially hold the string
    buffer = (char *)malloc(100 * sizeof(char));
    temp = readline(ifile, buffer);
    
    // create slim output buffer with extra character to null terminate the string
    output = (char *)malloc((temp.size+1) * sizeof(char));
    
    // close file reader
    fclose(ifile);
    
    // copy from buffer to slim output
    for(int i = 0; i < temp.size-1; i++)
    {
        output[i] = buffer[i];
    }
    // Null terminate the string
    output[temp.size - 1] = '\0';
    
    // Now free up buffer so no hanging pointers
    free(buffer);
    
    // return output
    return output;
}

struct lineread readline(FILE* ifile, char *buffer)
{
    char c;
    int counter = 0;
    struct lineread output = {0, buffer};
    // loop through file buffer passing chars to the buffer until '\n' is caught
    while((c = fgetc(ifile)) != 0) 
    {
        buffer[counter++] = c;
        output.size = counter;
        if(c == '\n') { break; }
    }
    return output;
}
EXPORT_SYMBOL(GPSNMEA);

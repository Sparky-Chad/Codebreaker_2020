docker run --rm --privileged multiarch/qemu-user-static:register --reset
docker build -t sparky-chad/alpine .
docker run -i sparky-chad/alpine ./gpslogger &
